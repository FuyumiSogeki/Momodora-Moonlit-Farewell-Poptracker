# Momodora Moonlit Farewell Randomizer Poptracker Package

This a poptracker package for Momodora Moonlit Farewell Randomizer.

This package was designed around full utilization of AP autotracking and provides quick updates to all unlocked sigils, skills and reachable locations.

## Installation

Download the latest build or source and place it in you Poptracker Packs folder.

## More Info

For the latest Momodora Moonlit Farewell Randomizer release, check [here](https://github.com/alditoOt/Momodora-Moonlit-Farewell-Randomizer/releases).